# MarketFlow — Business Model

## Positioning
MarketFlow is a starter storefront and commerce-analytics concept for small retailers, online sellers, and service businesses. The current `frontend/public/store.html` is a browser-only demonstration, not a production commerce service.

## Customer segments
- B2C: consumers browsing a small product catalog and placing a demonstration order.
- B2B: small shops and service businesses evaluating a simple digital storefront and sales reporting workflow.

## Revenue options to validate
1. Store setup fee: configure a catalog, branding, and initial product listings.
2. Monthly software/service fee: hosting, catalog maintenance, reporting, and support.
3. Optional add-ons: product photography, content creation, inventory import, and sales reports.
4. Future transaction fee only if a real payment/order infrastructure is added and disclosed.

## Suggested validation
- Interview 5–10 local sellers before choosing a price.
- Build one pilot store for a real merchant with permission.
- Measure visits, add-to-cart rate, completed paid orders, repeat purchases, and support time.
- Do not claim AI forecasting or AI recommendations until a model is implemented and tested on real data.

## Production requirements before accepting real orders
- Server-side database and authenticated merchant/admin roles.
- Server-side price and stock validation.
- Real payment gateway with signed webhook verification.
- Order confirmation, cancellation/refund workflow, shipping integration, and privacy notice.
- HTTPS, secrets management, backups, rate limits, logging, and security review.
- PDPA-compliant handling of customer name, phone, and delivery address.

## Current demo limitations
- Product catalog is hard-coded in the browser.
- Cart and demonstration orders are stored in browser `localStorage` only.
- No real payment, inventory reservation, shipping, customer accounts, or cross-device synchronization.
- Demo order records are not shared with the existing FastAPI analytics backend.
