# AI Intelligence Analytics Platform + MarketFlow Store Demo

A portfolio-ready starter project combining the original SENTRA analytics dashboard/API with a separate MarketFlow storefront prototype.

## What is included

- `backend/`: FastAPI authentication, event ingestion, analytics and anomaly scoring.
- `frontend/`: React + TypeScript analytics dashboard (Vite).
- `frontend/public/store.html`: responsive Thai storefront demo with product search/filter, cart, demo checkout, order history summary and CSV export.
- `docs/BUSINESS_MODEL.md`: customer segments, revenue options, validation plan and production checklist.
- `docker-compose.yml`: local multi-service development setup.

## Run locally

Requirements: Docker Desktop + Docker Compose.

```bash
cp .env.example .env
docker compose up --build
```

Open:
- Analytics dashboard: http://localhost:5173
- Store demo: http://localhost:5173/store.html
- API docs: http://localhost:8000/docs
- API health: http://localhost:8000/health

Demo analytics login:
- Email: `demo@aianalytics.local`
- Password: `DemoPass123!`

## Store demo usage

1. Open `/store.html`.
2. Search/filter the sample catalog.
3. Add items to cart.
4. Enter sample buyer details and submit a **demonstration order**.
5. Click **ร้านค้าของฉัน** to view demo sales totals and export CSV.

Demo orders are stored in that browser's `localStorage`. They are not sent to the backend and are not real paid orders.

## Important: demo vs production

This repository is a learning/portfolio prototype, not yet a production-ready e-commerce service. Do not accept real payments or collect real customer information with the demo checkout. Before commercial launch, add a persistent database, server-side order and inventory validation, merchant accounts, a payment gateway and verified webhooks, shipping/returns workflows, HTTPS, backups, security testing, and a PDPA privacy notice. See `docs/BUSINESS_MODEL.md`.

The anomaly score in the analytics API is statistical rule-based scoring, not a trained AI model. Avoid marketing it as a validated predictive AI model.

## Deployment notes

The React dashboard and static store can be hosted on a static frontend host. The FastAPI backend requires a Python-capable host and a persistent database for production. Configure `VITE_API_BASE` for the public API URL and set secure environment variables on the hosting provider. Never commit `.env` or real secrets.

## License

Add a license file before accepting external contributions or commercial reuse.
