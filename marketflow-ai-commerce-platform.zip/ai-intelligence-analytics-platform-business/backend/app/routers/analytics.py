from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import User
from ..dependencies import current_user
from ..analytics import dashboard_summary, timeseries, source_breakdown

router = APIRouter(prefix="/api/analytics", tags=["analytics"])

@router.get("/summary")
def summary(db: Session = Depends(get_db), user: User = Depends(current_user)):
    return dashboard_summary(db, user.id)

@router.get("/timeseries")
def series(days: int = Query(14, ge=1, le=90), db: Session = Depends(get_db),
           user: User = Depends(current_user)):
    return timeseries(db, user.id, days)

@router.get("/sources")
def sources(db: Session = Depends(get_db), user: User = Depends(current_user)):
    return source_breakdown(db, user.id)
